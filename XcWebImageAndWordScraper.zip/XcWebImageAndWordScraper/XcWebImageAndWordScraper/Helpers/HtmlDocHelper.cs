﻿using System;
using System.Net;
using HtmlAgilityPack;
using log4net;


namespace XcWebImageAndWordScraper.Helpers
{
    public class HtmlDocHelper : IHtmlDocHelper
    {
        private static readonly ILog s_logger = LogManager.GetLogger(typeof(HtmlDocHelper));
        public HtmlDocument GeHtmlDocument(string strUrl)
        {
            try
            {
                //Check for scheme - improper hack to handle urls without any scheme
                //Need to refactor
                if (!strUrl.Contains("http") && !strUrl.Contains("https"))
                {
                    strUrl = "http://" + strUrl;
                }
                // Fetch HEAD Data for better performance
                WebRequest request = WebRequest.Create(strUrl);
                request.Method = "HEAD";
                request.GetResponse();
            }
            catch (Exception ex)
            {
                //Issue with URL
                s_logger.ErrorFormat("Invalid URL Entered {0}", strUrl);
                return null;
            }

            // Create Uri from provided url input
            Uri url = new Uri(strUrl);

            // Initialize a WebClient
            WebClient client = new WebClient();

            // Download page Html
            string html = client.DownloadString(url);

            // Load the Html into HtmlAgilityPack
            HtmlDocument doc = new HtmlDocument();
            doc.LoadHtml(html);
            return doc;
        }
    }
}