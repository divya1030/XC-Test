﻿using System.Collections.Generic;

namespace XcWebImageAndWordScraper.Helpers.ImageScanner
{
    public interface IImageScanner
    {
        List<string> ListImageUrls(string siteUrl);
    }
}
