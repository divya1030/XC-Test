﻿using System;
using System.Collections.Generic;
using System.Linq;
using HtmlAgilityPack;
using log4net;
using XcWebImageAndWordScraper.Models;

namespace XcWebImageAndWordScraper.Helpers.ImageScanner
{
    public class ImageScanner : IImageScanner
    {
        private static readonly ILog s_logger = LogManager.GetLogger(typeof(ImageScanner));
        private readonly IHtmlDocHelper m_htmlDocHelper;
        public ImageScanner(IHtmlDocHelper htmlDocHelper)
        {
            m_htmlDocHelper = htmlDocHelper;
        }
      public  List<string> ListImageUrls(string siteUrl)
      {
          var htmlDocument = m_htmlDocHelper.GeHtmlDocument(siteUrl);
          var imagesList = new List<string>();
    
          s_logger.Debug("ListImageUrls Started");

            if (htmlDocument.DocumentNode.Descendants("img") == null)
            {
                s_logger.ErrorFormat("No Images on the site {0}",siteUrl);
                
                return null;
            }

          try
          {
              // Clean document of script tags 
              htmlDocument.DocumentNode.Descendants()
                  .Where(n => n.Name == "script" || n.Name == "noscript")
                  .ToList()
                  .ForEach(n => n.Remove());

              // Use LINQ to get all Image tags
              var foundImages = (from HtmlNode node in htmlDocument.DocumentNode.Descendants("img")
                  where (node.Attributes["src"] != null)
                  select new ImageModel
                  {
                      ImageUrl = node.Attributes["src"].Value
                  });
              imagesList = foundImages.Select(f => f.ImageUrl).ToList();
          }
          catch (Exception ex)
          {
              s_logger.ErrorFormat("Error occured while fetching Images on the site {0}. Error Message : {1}", siteUrl, ex.Message);
              return null;
          }
            return imagesList;
        }
    }
}