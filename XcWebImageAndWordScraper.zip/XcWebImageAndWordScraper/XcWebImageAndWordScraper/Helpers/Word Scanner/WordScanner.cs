﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using HtmlAgilityPack;
using log4net;
using XcWebImageAndWordScraper.Models;

namespace XcWebImageAndWordScraper.Helpers.Word_Scanner
{
    public class WordScanner : IWordScanner
    {
        private static readonly ILog s_logger = LogManager.GetLogger(typeof(WordScanner));
        private readonly IHtmlDocHelper m_htmlDocHelper;
        
        public WordScanner(IHtmlDocHelper htmlDocHelper)
        {
            m_htmlDocHelper = htmlDocHelper;
        }
       
        public List<WordCountModel> ListFrequentlyUsedWords(string siteUrl)
        {
            s_logger.Debug("ListFrequentlyUsedWords Started");
            var wordsList = new List<WordCountModel>();
            var wordCount = 0;
            try
            {
                Dictionary<string, int> textDict = new Dictionary<string, int>();

                var doc = m_htmlDocHelper.GeHtmlDocument(siteUrl);
                if (doc == null)
                    return null;
                foreach (var node in doc.DocumentNode.SelectSingleNode("//body").DescendantsAndSelf())
                {
                    if (node.NodeType == HtmlNodeType.Text && node.ParentNode.Name != "script")
                    {
                        MatchCollection matches = Regex.Matches(node.InnerText, @"\b(?:[a-z]{2,}|[ai])\b",
                            RegexOptions.IgnoreCase);

                        foreach (Match s in matches)
                        {
                            if (textDict.ContainsKey(s.Value))
                            {
                                textDict[s.Value]++;
                            }
                            else
                            {
                                textDict.Add(s.Value, 1);
                            }

                            wordCount++;
                        }
                    }
                }
                s_logger.Debug("Converting dictionary object to List");
                wordsList = GetObject(textDict);
            }
            catch (Exception ex)
            {
                s_logger.ErrorFormat("There was an error fetching the frequently used words from Site {0}. Error Message: {1}", siteUrl, ex.Message);
            }
            return wordsList;
        }

        private  List<WordCountModel> GetObject(Dictionary<string, int> dict)
        {
            var wordList = new List<WordCountModel>();
            foreach (var keyValuePair in dict)
            {
                var wordListItem = new WordCountModel();
                wordListItem.WordUsed = keyValuePair.Key;
                wordListItem.Count = keyValuePair.Value;
                
                wordList.Add(wordListItem);
            }

            var wordRankings = wordList
                .OrderByDescending(s=>s.Count)
                .Take(10)
                .ToList();
            return wordRankings;
        }
    }
}