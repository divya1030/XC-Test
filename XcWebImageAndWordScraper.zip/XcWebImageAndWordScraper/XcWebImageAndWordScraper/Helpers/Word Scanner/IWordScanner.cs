﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using XcWebImageAndWordScraper.Models;

namespace XcWebImageAndWordScraper.Helpers.Word_Scanner
{
    public interface IWordScanner
    {
        List<WordCountModel> ListFrequentlyUsedWords(string siteUrl);

    }
}
