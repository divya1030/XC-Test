﻿using System.Collections.Generic;
using System.Web.Mvc;
using log4net;
using XcWebImageAndWordScraper.Helpers.ImageScanner;
using XcWebImageAndWordScraper.Helpers.Word_Scanner;
using XcWebImageAndWordScraper.Models;

namespace XcWebImageAndWordScraper.Controllers
{
    public class HomeController : Controller
    {
        private static readonly ILog s_logger = LogManager.GetLogger(typeof(HomeController));

        private readonly IImageScanner m_imageScanner;
        private readonly IWordScanner m_wordScanner;
        public HomeController(IImageScanner imageScanner,IWordScanner wordScanner)
        {
            m_imageScanner = imageScanner;
            m_wordScanner = wordScanner;
        }
        public ActionResult Index()
        {
            s_logger.Debug("Index action method");
            return View();
        }

        [HttpPost]
        public ActionResult ImagesDisplay(string hdnSiteUrl)
        {
            ViewBag.Message = "Images Display";

            var vm = new DisplayViewModel();
            vm.ImagesUrlList = new List<string>();

            var ImageModelList =  m_imageScanner.ListImageUrls(hdnSiteUrl);
            if (ImageModelList != null)
            {
                vm.ImagesUrlList.AddRange(ImageModelList);
            }
            else
            {
                s_logger.Debug("No Images fetched from the site");
            }
        

            return View("ImagesDisplay",vm);
        }

        public ActionResult WordCount(string hdnUrl)
        {
            ViewBag.Message = "Frequently Used Words Display";

            var vm = new DisplayViewModel();
            vm.WordsList = new List<WordCountModel>();

            var wordsList = m_wordScanner.ListFrequentlyUsedWords(hdnUrl);
            if (wordsList != null)
            {
                vm.WordsList.AddRange(wordsList);
            }
            else
            {
                s_logger.Debug("Word List count is 0");
            }

            return View("WordCount",vm);
        }
    }
}