﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace XcWebImageAndWordScraper.Models
{
    public class ImageModel
    {
        public string ImageUrl { get; set; }
        public string ImageAltText { get; set; }
    }
}