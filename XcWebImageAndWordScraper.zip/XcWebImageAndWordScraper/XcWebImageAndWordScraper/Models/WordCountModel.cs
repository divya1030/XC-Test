﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace XcWebImageAndWordScraper.Models
{
    public class WordCountModel
    {
        public string WordUsed { get; set; }

        public int Count { get; set; }
    }
}