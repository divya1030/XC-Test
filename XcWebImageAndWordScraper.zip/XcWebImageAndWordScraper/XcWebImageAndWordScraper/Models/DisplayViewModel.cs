﻿using System.Collections.Generic;

namespace XcWebImageAndWordScraper.Models
{
    public class DisplayViewModel
    {
        public List<string> ImagesUrlList { get; set; }

        public List<WordCountModel> WordsList { get; set; }
    }
}