﻿using System.Collections.Generic;
using Moq;
using XcWebImageAndWordScraper.Helpers;
using Xunit;
using HtmlAgilityPack;
using XcWebImageAndWordScraper.Helpers.ImageScanner;

namespace UnitTests.HelperTests
{
    public class ImageScannerTests
    {
        private Mock<IHtmlDocHelper> htmlDocHelperMock;

        public ImageScannerTests()
        {
            htmlDocHelperMock = new Mock<IHtmlDocHelper>();
            htmlDocHelperMock.SetupAllProperties();

        }

        [Fact]
        public void ListImageUrlsTestWithValues()
        {
            var htmlContent = "<!DOCTYPE html>\r\n<html>\r\n<body>\r\n\r\n<img src=\"w3schools.jpg\" alt=\"W3Schools.com\" width=\"104\" height=\"142\">\r\n\r\n</body>\r\n</html>\r\n";
            var htmlDoc = new HtmlDocument();
            htmlDoc.LoadHtml(htmlContent);
            htmlDocHelperMock.Setup(h => h.GeHtmlDocument(It.IsAny<string>())).Returns(htmlDoc);

            var imageScanner = new ImageScanner(htmlDocHelperMock.Object);
            List<string> result = imageScanner.ListImageUrls("Test Site Url");

            Assert.Single(result);
        }

        [Fact]
        public void ListImageUrlsTestNoValues()
        {
            var htmlContent = "";
            var htmlDoc = new HtmlDocument();
            htmlDoc.LoadHtml(htmlContent);
            htmlDocHelperMock.Setup(h => h.GeHtmlDocument(It.IsAny<string>())).Returns(htmlDoc);

            var imageScanner = new ImageScanner(htmlDocHelperMock.Object);
            List<string> result = imageScanner.ListImageUrls("Test Site Url");

            Assert.Empty(result);
        }
    }
}
