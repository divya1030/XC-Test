﻿using System.Collections.Generic;
using Moq;
using XcWebImageAndWordScraper.Helpers;
using Xunit;
using HtmlAgilityPack;
using XcWebImageAndWordScraper.Helpers.Word_Scanner;
using XcWebImageAndWordScraper.Models;

namespace UnitTests.HelperTests
{
    public class WordScannerTests
    {
        private Mock<IHtmlDocHelper> htmlDocHelperMock;

        public WordScannerTests()
        {
            htmlDocHelperMock = new Mock<IHtmlDocHelper>();
            htmlDocHelperMock.SetupAllProperties();
        }

        [Fact]
        public void ListFrequentlyUsedWordsTestWithValues()
        {
            var htmlContent = "<!DOCTYPE html><html><body><h1>My First Heading</h1><p>My first paragraph.First Sentence.First Test Word</p></body></html>";
            var htmlDoc = new HtmlDocument();
            htmlDoc.LoadHtml(htmlContent);
            htmlDocHelperMock.Setup(h => h.GeHtmlDocument(It.IsAny<string>())).Returns(htmlDoc);

            var imageScanner = new WordScanner(htmlDocHelperMock.Object);
            List<WordCountModel> result = imageScanner.ListFrequentlyUsedWords("Test Site Url");

            Assert.Equal(8,result.Count);
        }
       
    }
}
