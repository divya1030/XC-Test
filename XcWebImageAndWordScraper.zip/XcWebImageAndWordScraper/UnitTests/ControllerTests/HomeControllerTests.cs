﻿using System.Collections.Generic;
using System.Web.Mvc;
using Moq;
using XcWebImageAndWordScraper.Controllers;
using XcWebImageAndWordScraper.Helpers.ImageScanner;
using XcWebImageAndWordScraper.Helpers.Word_Scanner;
using XcWebImageAndWordScraper.Models;
using Xunit;

namespace UnitTests.ControllerTests
{
 
           /// <summary>
           /// Unit Tests For Home Controller
           /// </summary>
    public class HomeControllerTests
    {
        private Mock<IImageScanner> imageScannerMock;
        private Mock<IWordScanner> wordScannerMock;
        
        public HomeControllerTests()
        {
            imageScannerMock = new Mock<IImageScanner>();
            imageScannerMock.SetupAllProperties();
            wordScannerMock = new Mock<IWordScanner>();
            wordScannerMock.SetupAllProperties();
        }

        [Fact]
        public void ReturnsViewResultWithViewNameTest()
        {
            var controller = new HomeController(null,null);
            var result = controller.Index();

            // Assert
            var viewResult = Assert.IsType<ViewResult>(result);
            Assert.Empty(viewResult.ViewName);
        }

        [Fact]
        public void ImagesDisplayTestWithValues()
        {
            var testImagesUrlList = new List<string>() {"Test Url"};
            imageScannerMock.Setup(m => m.ListImageUrls(It.IsAny<string>())).Returns(testImagesUrlList);
            var controller = new HomeController(imageScannerMock.Object,null);
           var result=(ViewResult) controller.ImagesDisplay("Test Site Url");
            var model = (DisplayViewModel) result.Model;

            //Assert
            Assert.NotNull(result);
            Assert.Equal(model.ImagesUrlList.Count,testImagesUrlList.Count);
        }

        [Fact]
        public void WordsCountTestWithValues()
        {
            var testWordsList = new List<WordCountModel>();
            var testModel = new WordCountModel();
            testModel.WordUsed = "Test";
            testModel.Count = 10;
            testWordsList.Add(testModel);

            wordScannerMock.Setup(m => m.ListFrequentlyUsedWords(It.IsAny<string>())).Returns(testWordsList);
            var controller = new HomeController(null, wordScannerMock.Object);
            var result = (ViewResult)controller.WordCount("Test Site Url");
            var model = (DisplayViewModel)result.Model;

            //Assert
            Assert.NotNull(result);
            Assert.Equal(model.WordsList.Count, testWordsList.Count);
        }
    }
}
